500 - Internal Server Error
===========================

.. module:: pyrogram.errors.InternalServerError

.. automodule:: pyrogram.errors.exceptions.internal_server_error_500
    :members:
