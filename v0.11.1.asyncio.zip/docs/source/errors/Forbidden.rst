403 - Forbidden
===============

.. module:: pyrogram.errors.Forbidden

.. automodule:: pyrogram.errors.exceptions.forbidden_403
    :members:
