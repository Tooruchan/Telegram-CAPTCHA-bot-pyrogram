406 - Not Acceptable
====================

.. module:: pyrogram.errors.NotAcceptable

.. automodule:: pyrogram.errors.exceptions.not_acceptable_406
    :members:
