520 - Unknown Error
===================

.. module:: pyrogram.errors.UnknownError

.. autoexception:: pyrogram.errors.rpc_error.UnknownError
    :members:
