400 - Bad Request
=================

.. module:: pyrogram.errors.BadRequest

.. automodule:: pyrogram.errors.exceptions.bad_request_400
    :members:
