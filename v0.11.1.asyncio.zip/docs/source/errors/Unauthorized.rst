401 - Unauthorized
==================

.. module:: pyrogram.errors.Unauthorized

.. automodule:: pyrogram.errors.exceptions.unauthorized_401
    :members:
