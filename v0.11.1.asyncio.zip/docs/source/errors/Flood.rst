420 - Flood
===========

.. module:: pyrogram.errors.Flood

.. automodule:: pyrogram.errors.exceptions.flood_420
    :members:
