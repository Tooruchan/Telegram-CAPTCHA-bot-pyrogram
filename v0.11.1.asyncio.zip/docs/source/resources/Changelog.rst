Changelog
=========

Currently, all Pyrogram release notes live inside the GitHub repository web page:
https://github.com/pyrogram/pyrogram/releases

(You will be automatically redirected in 10 seconds.)

.. raw:: html

    <meta http-equiv="refresh" content="10; URL=https://github.com/pyrogram/pyrogram/releases"/>