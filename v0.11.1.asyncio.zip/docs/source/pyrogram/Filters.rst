Filters
=======

.. autoclass:: pyrogram.Filters
    :members:
