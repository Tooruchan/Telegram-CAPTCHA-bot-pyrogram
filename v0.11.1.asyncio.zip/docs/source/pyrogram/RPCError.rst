RPCError
========

.. autoexception:: pyrogram.RPCError
    :members:

.. toctree::
    ../errors/SeeOther
    ../errors/BadRequest
    ../errors/Unauthorized
    ../errors/Forbidden
    ../errors/NotAcceptable
    ../errors/Flood
    ../errors/InternalServerError
    ../errors/UnknownError
