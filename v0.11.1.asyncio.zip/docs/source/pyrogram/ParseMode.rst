ParseMode
=========

.. autoclass:: pyrogram.ParseMode
    :members:
    :undoc-members:
