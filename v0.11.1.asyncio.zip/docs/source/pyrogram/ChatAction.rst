ChatAction
==========

.. autoclass:: pyrogram.ChatAction
    :members:
